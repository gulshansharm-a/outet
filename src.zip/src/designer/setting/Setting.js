import React, { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { update_setting } from '../../redux/actions';
import settingArray from "../../redux/settingArray";

const Setting = () => {
  const dispatch = useDispatch();
  const selectedSettingUID = useSelector((state) => state.selectedSettingUID);
  const tree = useSelector((state) => state.tree) || [];
  
  useEffect(() => {
    const element = tree.find(item => item.uID === selectedSettingUID);

    if (element) {
      console.log(element);
    } else {
      console.log('Element with selectedSettingUID not found.');
    }
  }, [selectedSettingUID, dispatch, tree]);

  return (
    <>
      <h3>Select the setting</h3>
      <p>{selectedSettingUID}</p>
  
      {tree.length > 0 ? (
        tree.map((element) =>
          element.uID === selectedSettingUID
            ? element.settings?.map((setting, index) => {
                const matchingSetting = settingArray.find(
                  (item) => item.settingId === setting.settingId
                );
                return (
                  <div key={`${element.id}-${index}`}>
                    {matchingSetting ? (
                      React.cloneElement(matchingSetting.setting, {
                        sectionID: element.id,
                        settingId: setting.id,
                      })
                    ) : (
                      <p>Setting not found</p>
                    )}
                  </div>
                );
              })
            : null
        )
      ) : (
        <p>No data available.</p>
      )}
    </>
  );
  
};

export default Setting;
