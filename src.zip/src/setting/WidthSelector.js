import React, { useState } from "react";
import { ToggleButton, ToggleButtonGroup } from "@mui/material";
import { useDispatch } from "react-redux";
import { update_setting } from "../redux/actions";

const WidthSelector = ({ sectionID, settingId }) => {
    const dispatch = useDispatch();
    const [selectedSize, setSelectedSize] = useState("Medium"); // Default selection

    const handleSizeChange = (event, newSize) => {
        if (newSize !== null) {
            setSelectedSize(newSize);
            dispatch(update_setting(sectionID, settingId, newSize));
        }
    };

    return (
        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <span style={{ fontWeight: "bold" }}>Width</span>
            <ToggleButtonGroup
                value={selectedSize}
                exclusive
                onChange={handleSizeChange}
                aria-label="Width selection"
                size="small"
            >
                <ToggleButton value="Small">Small</ToggleButton>
                <ToggleButton value="Medium">Medium</ToggleButton>
                <ToggleButton value="Large">Large</ToggleButton>
            </ToggleButtonGroup>
        </div>
    );
};

export default WidthSelector;