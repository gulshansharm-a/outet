import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { update_setting } from "../redux/actions";

const SliderField = ({ sectionID, settingId, title = "Adjust Value", min = 0, max = 100, step = 1 }) => {
    const dispatch = useDispatch();

    // Get initial value from Redux store
    const initialValue = useSelector(state => 
        state.settings?.[sectionID]?.[settingId] || min
    );

    const [value, setValue] = useState(initialValue);

    const handleChange = (e) => {
        const newValue = Number(e.target.value);
        setValue(newValue); // Update local state
        dispatch(update_setting(sectionID, settingId, newValue));
    };

    return (
        <div>
            <label htmlFor={`slider-${settingId}`}>{title}: {value}</label>
            <input
                id={`slider-${settingId}`}
                type="range"
                min={min}
                max={max}
                step={step}
                value={value}
                onChange={handleChange}
                aria-label={title}
            />
        </div>
    );
};

export default SliderField;
