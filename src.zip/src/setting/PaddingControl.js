import React, { useState } from "react";
import { Slider, TextField, Typography, Box } from "@mui/material";
import { useDispatch } from "react-redux";
import { update_setting } from "../redux/actions";

const PaddingControl = ({ sectionID, settingId }) => {
    const dispatch = useDispatch();
    const [padding, setPadding] = useState({ top: 36, bottom: 36 }); // Default values

    const handleChange = (side, newValue) => {
        const updatedPadding = { ...padding, [side]: newValue };
        setPadding(updatedPadding);
        dispatch(update_setting(sectionID, settingId, updatedPadding));
    };

    return (
        <Box sx={{ width: 300, display: "flex", flexDirection: "column", gap: 2 }}>
            <Typography variant="h6" fontWeight="bold">Padding</Typography>

            {/* Top Padding */}
            <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
                <Typography>Top</Typography>
                <Slider
                    value={padding.top}
                    onChange={(e, value) => handleChange("top", value)}
                    min={0}
                    max={100}
                    step={1}
                    sx={{ flexGrow: 1 }}
                />
                <TextField
                    value={padding.top}
                    onChange={(e) => handleChange("top", Number(e.target.value))}
                    size="small"
                    type="number"
                    inputProps={{ min: 0, max: 100 }}
                    sx={{ width: 60 }}
                />
                <Typography>px</Typography>
            </Box>

            {/* Bottom Padding */}
            <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
                <Typography>Bottom</Typography>
                <Slider
                    value={padding.bottom}
                    onChange={(e, value) => handleChange("bottom", value)}
                    min={0}
                    max={100}
                    step={1}
                    sx={{ flexGrow: 1 }}
                />
                <TextField
                    value={padding.bottom}
                    onChange={(e) => handleChange("bottom", Number(e.target.value))}
                    size="small"
                    type="number"
                    inputProps={{ min: 0, max: 100 }}
                    sx={{ width: 60 }}
                />
                <Typography>px</Typography>
            </Box>
        </Box>
    );
};

export default PaddingControl;