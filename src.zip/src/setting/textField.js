import React from "react";
import { useDispatch } from "react-redux";
import { update_setting } from "../redux/actions";

const TextField = ({ sectionID, settingId }) => {
    const dispatch = useDispatch();

    const handleChange = (e) => {
        const newValue = e.target.value;
        dispatch(update_setting(sectionID, settingId, newValue));
    };

    return (
        <>
            <h1>Title</h1>
            <input 
                type="text" 
                onChange={handleChange} 
                placeholder="Enter text"
            />
        </>
    );
};

export default TextField;
