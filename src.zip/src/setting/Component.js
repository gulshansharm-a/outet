import React, { useState }  from "react";
import { CopyOutlined,AppstoreOutlined,
  CalendarOutlined, CommentOutlined,
  DownloadOutlined, DownOutlined,
  EllipsisOutlined,
  HeartOutlined,
  LikeOutlined,
  MailOutlined,
  MobileOutlined,
  ShareAltOutlined,
  StarOutlined,
  WarningOutlined,
  LinkOutlined,
  DotChartOutlined,
  InboxOutlined,SmileOutlined,UserOutlined, MinusOutlined, PlusOutlined} from "@ant-design/icons";
import {
  Button,
  Cascader,
  ColorPicker,
  DatePicker,
  Input,
  InputNumber,
  Select,
  Space,
  TimePicker,
  Tooltip,
  TreeSelect,
  Flex,
  Spin,
  Result,
  AutoComplete,
  Checkbox,
  Radio,
  Col, 
  Row,
  Slider,
  Switch,
  Avatar,
  Badge,Divider,Form,Dropdown,Menu
} from "antd";

const { Option } = Select;
const { TreeNode } = TreeSelect;
const { TextArea } = Input;
/** Compact Input Group with Copy Button */
export const CompactInputGroup = () => (
  <Space.Compact block>
    <Input style={{ width: "calc(100% - 200px)" }} defaultValue="git@github.com:ant-design/ant-design.git" />
    <Tooltip title="copy git url">
      <Button icon={<CopyOutlined />} />
    </Tooltip>
  </Space.Compact>
);

/** Compact Select & Input */
export const CompactSelectInput = () => (
  <Space.Compact block>
    <Select defaultValue="Zhejiang" allowClear>
      <Option value="Zhejiang">Zhejiang</Option>
      <Option value="Jiangsu">Jiangsu</Option>
    </Select>
    <Input style={{ width: "50%" }} defaultValue="Xihu District, Hangzhou" />
  </Space.Compact>
);

/** Date Picker with Input & Button */
export const DatePickerGroup = () => (
  <Space.Compact block>
    <DatePicker.RangePicker style={{ width: "70%" }} />
    <Input style={{ width: "30%" }} defaultValue="input content" />
    <Button type="primary">Query</Button>
  </Space.Compact>
);

/** Time Picker and Cascader */
export const TimePickerCascader = () => (
  <Space.Compact block>
    <TimePicker style={{ width: "50%" }} />
    <Cascader
      style={{ width: "50%" }}
      options={[
        {
          value: "zhejiang",
          label: "Zhejiang",
          children: [{ value: "hangzhou", label: "Hangzhou", children: [{ value: "xihu", label: "West Lake" }] }],
        },
        {
          value: "jiangsu",
          label: "Jiangsu",
          children: [{ value: "nanjing", label: "Nanjing", children: [{ value: "zhonghuamen", label: "Zhong Hua Men" }] }],
        },
      ]}
      placeholder="Select Address"
    />
  </Space.Compact>
);

/** Spin Loader Component */
export const SpinLoader = () => (
  <Flex align="center" gap="middle">
    <Spin size="small" />
    <Spin />
    <Spin size="large" />
  </Flex>
);

//success Message
export const Successmessage=()=>(
  <Result
  status="success"
  title="Successfully Purchased Cloud Server ECS!"
  subTitle="Order number: 2017182818828182881 Cloud server configuration takes 1-5 minutes, please wait."
  extra={[
    <Button type="primary" key="console">
      Go Console
    </Button>,
    <Button key="buy">Buy Again</Button>,
  ]}
/>
);

// Info Message
export const Info=()=>(
  <Result
  title="Your operation has been executed"
  extra={
    <Button type="primary" key="console">
      Go Console
    </Button>
  }
/>
);

export const Warning=()=>(
  <Result
  status="warning"
  title="There are some problems with your operation."
  extra={
    <Button type="primary" key="console">
      Go Console
    </Button>
  }
/>
);

export const Customicon=()=>(
  <Result
  icon={<SmileOutlined />}
  title="Great, we have done all the operations!"
  extra={<Button type="primary">Next</Button>}
/>
);

export const Error500=()=>(
  <Result
  status="500"
  title="500"
  subTitle="Sorry, something went wrong."
  extra={<Button type="primary">Back Home</Button>}
/>
);

export const Error404=()=>(
  <Result
  status="404"
  title="404"
  subTitle="Sorry, the page you visited does not exist."
  extra={<Button type="primary">Back Home</Button>}
/>
);

export const Error403=()=>(
  <Result
  status="403"
  title="403"
  subTitle="Sorry, you are not authorized to access this page."
  extra={<Button type="primary">Back Home</Button>}
/>
);
//custom input Component
export const CustomText=()=>(
  <AutoComplete
  style={{
    width: 200,
  }}
>
  <TextArea
    placeholder="input here"
    className="custom"
    style={{
      height: 50,
    }}  />
</AutoComplete>
);

// input Text
export const Inputtext=()=>(
  <AutoComplete
  style={{
    width: 200,
  }}
  placeholder="input here"
/>
);

export const Twoinput=()=>(
 <div>
   <AutoComplete
  style={{
    width: 200,
  }}
  placeholder="input here"
/>
<br />
<br />
<AutoComplete
  style={{
    width: 200,
  }}
  placeholder="control mode"
/>
 </div>
);

export const InputSearch=()=>(
  <AutoComplete
  popupMatchSelectWidth={252}
  style={{
    width: 300,
  }}
  size="large"
>
  <Input.Search size="large" placeholder="input here" enterButton />
</AutoComplete>
);

export const InputCheckbox=()=>(
  <Checkbox>Checkbox</Checkbox>
);

export const InputColorPicker=()=>(
  <ColorPicker defaultValue="#1677ff" />
);

export const Number=()=>(
  <InputNumber min={1} max={10} defaultValue={3} />
);

export const ResetNumberbutton=()=>(
  <Space>
      <InputNumber min={1} max={10} defaultValue={50}  />
      <Button
        type="primary"
      >
        Reset
      </Button>
    </Space>
);

export const InputSelect=()=>(
  <Select
  mode="multiple"
  style={{
    width: '100%',
  }}
  placeholder="select one country"
  defaultValue={['India']}

  optionRender={(option) => (
    <Space>
      <span role="img"> 
      </span>
    </Space>
  )}
/>
);

export const Clickbutton=()=>(
  <Radio.Group value="topLeft" onchange="topLeft">
  <Radio.Button value="topLeft">topLeft</Radio.Button>
  <Radio.Button value="topRight">topRight</Radio.Button>
  <Radio.Button value="bottomLeft">bottomLeft</Radio.Button>
  <Radio.Button value="bottomRight">bottomRight</Radio.Button>
</Radio.Group>
);

export const SliderInput=()=>(
  <Row>
  <Col span={12}>
    <Slider
      min={1}
      max={20}
    />
  </Col>
  <Col span={4}>
    <InputNumber
      min={1}
      max={20}
      style={{
        margin: '0 16px',
      }}
    />
  </Col>
</Row>
);
const SwitchButton=()=>(<Switch defaultChecked />);
const Avataricon=()=>(
  <Space direction="vertical" size={16}>
    <Space wrap size={16}>
      <Avatar size={64} icon={<UserOutlined />} />
      <Avatar size="large" icon={<UserOutlined />} />
      <Avatar icon={<UserOutlined />} />
      <Avatar size="small" icon={<UserOutlined />} />
      <Avatar size={14} icon={<UserOutlined />} />
    </Space>
  </Space>
);

const PlueMinusInput=()=>(
  <Space direction="vertical">
  <Space size="large">
    <Space.Compact>
      <Button  icon={<MinusOutlined />} />
      <Button  icon={<PlusOutlined />} />
    </Space.Compact>
  </Space>
</Space>
);
const  HandoneSize=()=>(
  <Flex gap="middle" vertical>
  <Divider />
  <Form
    layout="inline"
    style={{
      margin: '16px 0',
    }}
  >
    <Space size={16} wrap>
      <Form.Item label="Active">
        <Switch />
      </Form.Item>
      <Form.Item label="Button and Input Block">
        <Switch  />
      </Form.Item>
      <Form.Item label="Size">
        <Radio.Group >
          <Radio.Button value="default">Default</Radio.Button>
          <Radio.Button value="large">Large</Radio.Button>
          <Radio.Button value="small">Small</Radio.Button>
        </Radio.Group>
      </Form.Item>
      <Form.Item label="Button Shape">
        <Radio.Group >
          <Radio.Button value="default">Default</Radio.Button>
          <Radio.Button value="square">Square</Radio.Button>
          <Radio.Button value="round">Round</Radio.Button>
          <Radio.Button value="circle">Circle</Radio.Button>
        </Radio.Group>
      </Form.Item>
      <Form.Item label="Avatar Shape">
        <Radio.Group >
          <Radio.Button value="square">Square</Radio.Button>
          <Radio.Button value="circle">Circle</Radio.Button>
        </Radio.Group>
      </Form.Item>
    </Space>
  </Form>
</Flex>
);

export const ToolBox=()=>(
<div> <Space.Compact block>
      <Tooltip title="Like">
        <Button icon={<LikeOutlined />} />
      </Tooltip>
      <Tooltip title="Comment">
        <Button icon={<CommentOutlined />} />
      </Tooltip>
      <Tooltip title="Star">
        <Button icon={<StarOutlined />} />
      </Tooltip>
      <Tooltip title="Heart">
        <Button icon={<HeartOutlined />} />
      </Tooltip>
      <Tooltip title="Share">
        <Button icon={<ShareAltOutlined />} />
      </Tooltip>
      <Tooltip title="Download">
        <Button icon={<DownloadOutlined />} />
      </Tooltip>
    </Space.Compact>
   </div>
);

export const Dropmenu=()=>(
  <Dropdown
  menu={[
    {
      key: '1',
      type: 'group',
      label: 'Group title',
      children: [
        {
          key: '1-1',
          label: '1st menu item',
        },
        {
          key: '1-2',
          label: '2nd menu item',
        },
      ],
    },
    {
      key: '2',
      label: 'sub menu',
      children: [
        {
          key: '2-1',
          label: '3rd menu item',
        },
        {
          key: '2-2',
          label: '4th menu item',
        },
      ],
    },
    {
      key: '3',
      label: 'disabled sub menu',
      disabled: true,
      children: [
        {
          key: '3-1',
          label: '5d menu item',
        },
        {
          key: '3-2',
          label: '6th menu item',
        },
      ],
    },
  ]}
>
  <a onClick={(e) => e.preventDefault()}>
    <Space>
      Cascading menu
      <DownOutlined />
    </Space>
  </a>
</Dropdown>
);

const App = () => (
  <>
    <CompactInputGroup />
    <CompactSelectInput />
    <DatePickerGroup />
    <TimePickerCascader />
    <SpinLoader/>
    <Successmessage/>
    <Info/>
    <Warning/>
    <Customicon/>
    <Error500/>
    <Error404/>
    <CustomText/>
    <Inputtext/>
    <Twoinput/>
    <InputSearch/>
    <InputCheckbox/>
    <InputColorPicker/>
    <Number/>
    <ResetNumberbutton/>
    <InputSelect/>
    <Clickbutton/>
    <SliderInput/>
    <SwitchButton/>
    <Avataricon/>
    <PlueMinusInput/>
    <HandoneSize/>
    <ToolBox/> 
  </>
);

export default App;
