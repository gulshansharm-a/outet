import React from "react";
const Image =  () =>{
    return( <>
        <h1>Title</h1>
        <input type="file"></input>
    </>)
}

export default Image;