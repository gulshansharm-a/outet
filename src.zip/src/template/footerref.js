import React from "react";
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import 'swiper/css/effect-fade';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import {Autoplay,EffectFade} from 'swiper/modules';

const productarray = [
    { id: 1, name: "Nike Shoes", image: "https://images.unsplash.com/photo-1715773150368-55945728385a?q=80&w=2076&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" },
    { id: 2, name: "Smartphone", image: "https://images.unsplash.com/photo-1515955656352-a1fa3ffcd111?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" },
    { id: 3, name: "Backpack", image: "" },
    
  ];

  const imgStyle={
    'width':'100%',
    'height':'80vh',
    'objectFit': "cover",
  }    
  
  const container={
    'position':'relative',
    'text-align':'center',
  }
  
const Products = () => {
 return(
  <>
  <Swiper spaceBetween={30} effect={'fade'}  modules={[Autoplay,EffectFade]}  autoplay={{delay: 2500,disableOnInteraction: false,}} className="mySwiper"
  >
    {
   productarray.map((img)=>(
    <SwiperSlide>
    <div style={container}>
    <img style={imgStyle} src={img.image} />
    </div>
  </SwiperSlide>
   ))
    }
  </Swiper>
</>
 );
};

export { Products, productarray};

