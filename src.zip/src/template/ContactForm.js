import React from "react";

const ContactForm = () => {
  // Define styles as variables
  const formContainerStyle = {
    width: "50%",
    margin: "auto",
    padding: "20px",
    border: "1px solid #ccc",
    borderRadius: "5px",
  };

  const formGroupStyle = {
    display: "flex",
    gap: "10px",
    marginBottom: "10px",
  };

  const inputStyle = {
    width: "100%",
    padding: "8px",
    border: "1px solid #ccc",
    borderRadius: "4px",
  };

  const buttonStyle = {
    backgroundColor: "black",
    color: "white",
    padding: "10px 15px",
    border: "none",
    cursor: "pointer",
  };

  // Define form elements as variables
  const formTitle = "Contact form";

  const nameField = <input type="text" placeholder="Name" style={inputStyle} />;
  const emailField = <input type="email" placeholder="Email *" style={inputStyle} />;
  const phoneField = <input type="text" placeholder="Phone number" style={inputStyle} />;
  const commentField = <textarea placeholder="Comment" style={inputStyle}></textarea>;

  const submitButton = <button style={buttonStyle}>Send</button>;

  return (
    <div style={formContainerStyle}>
      <h2>{formTitle}</h2>
      <div style={formGroupStyle}>
        {nameField} {emailField}
      </div>
      <div style={formGroupStyle}>{phoneField}</div>
      <div style={formGroupStyle}>{commentField}</div>
      {submitButton}
    </div>
  );
};

export default ContactForm;
