import React, { useState } from "react";

const ImageWithText = () => {
  const [position, setPosition] = useState("middle"); // 'top', 'middle', 'bottom'
  const [alignment, setAlignment] = useState("center"); // 'left', 'center', 'right'
  const [width, setWidth] = useState("large"); // 'small', 'medium', 'large'
  const [placement, setPlacement] = useState("image-first"); // 'image-first', 'text-first'

  const contentData = {
    title: "Image with text",
    description:
      "Pair text with an image to focus on your chosen product, collection, or blog post. Add details on availability, style, or even provide a review.",
    buttonText: "Button label",
    imageUrl:
      "https://images.unsplash.com/photo-1715773150368-55945728385a?q=80&w=2076&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
  };

  const getAlignmentStyles = (align) => ({
    textAlign: align,
    alignItems: align === "left" ? "flex-start" : align === "right" ? "flex-end" : "center",
  });

  const getPositionStyles = (pos) => ({
    justifyContent: pos === "top" ? "flex-start" : pos === "bottom" ? "flex-end" : "center",
  });

  const getWidthStyles = (size) => {
    switch (size) {
      case "small":
        return { maxWidth: "600px" };
      case "medium":
        return { maxWidth: "800px" };
      case "large":
        return { maxWidth: "1000px" };
      default:
        return {};
    }
  };

  const styles = {
    container: {
      padding: "20px",
    },
    controls: {
      marginBottom: "20px",
      padding: "10px",
      border: "1px solid #ddd",
      backgroundColor: "#f9f9f9",
    },
    section: {
      display: "flex",
      flexDirection: placement === "image-first" ? "row" : "row-reverse",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "20px",
      border: "1px solid #ddd",
      borderRadius: "8px",
      margin: "auto",
      ...getWidthStyles(width),
    },
    image: { width: "40%", borderRadius: "8px" },
    textContainer: {
      width: "55%",
      display: "flex",
      flexDirection: "column",
      ...getAlignmentStyles(alignment),
      ...getPositionStyles(position),
    },
    title: { fontSize: "22px", fontWeight: "bold", marginBottom: "10px" },
    description: { fontSize: "14px", color: "#555", marginBottom: "10px" },
    button: {
      padding: "8px 16px",
      backgroundColor: "#444",
      color: "#fff",
      border: "none",
      borderRadius: "4px",
      cursor: "pointer",
    },
  };

  return (
    <div style={styles.container}>
      {/* Controls (Fixed at the top) */}
      <div style={styles.controls}>
        <h4>Controls</h4>

        <label>Width:</label>
        <button onClick={() => setWidth("small")}>Small</button>
        <button onClick={() => setWidth("medium")}>Medium</button>
        <button onClick={() => setWidth("large")}>Large</button>

        <br /><br />

        <label>Placement:</label>
        <button onClick={() => setPlacement("image-first")}>Image first</button>
        <button onClick={() => setPlacement("text-first")}>Text first</button>

        <br /><br />

        <label>Position:</label>
        <button onClick={() => setPosition("top")}>Top</button>
        <button onClick={() => setPosition("middle")}>Middle</button>
        <button onClick={() => setPosition("bottom")}>Bottom</button>

        <br /><br />

        <label>Alignment:</label>
        <button onClick={() => setAlignment("left")}>Left</button>
        <button onClick={() => setAlignment("center")}>Center</button>
        <button onClick={() => setAlignment("right")}>Right</button>
      </div>

      {/* Image with Text Section (Updates dynamically) */}
      <div style={styles.section}>
        <img src={contentData.imageUrl} alt="Product" style={styles.image} />
        <div style={styles.textContainer}>
          <h3 style={styles.title}>{contentData.title}</h3>
          <p style={styles.description}>{contentData.description}</p>
          <button style={styles.button}>{contentData.buttonText}</button>
        </div>
      </div>
    </div>
  );
};

export default ImageWithText;
