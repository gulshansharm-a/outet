import React from 'react';
import { useSelector } from 'react-redux';
import { selectSettingValue } from '../redux/selectors';

const SettingValue = ({ elementId }) => {
  const settingValue = useSelector((state) =>
    selectSettingValue(state, 1222, 121)
  );

  return (
    <div>
      <h3>Setting Value</h3>
      {settingValue !== null ? (
        <p>Value: {settingValue}</p>
      ) : (
        <p>Setting not found.</p>
      )}
    </div>
  );
};

export default SettingValue;
