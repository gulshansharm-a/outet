import React, { useState } from "react";

const Cardrow = () => {
  const [boxDirection] = useState('left');
  const boxdirection = (boxDirection) => {
    const mapping = {
        'left': { flexDirection:'row'},
        'right': { flexDirection: 'row-reverse'},
    };
    return mapping[boxDirection] || mapping['left'];
  };
//change display size
const [displaysize] = useState('medium');
const Displaysize = (displaysize) => {
  const mapping = {
      'small': { height:'10rem'},
      'medium': { height: '20rem'},
      'large': { height:'30rem'},
  };
  return mapping[displaysize] || mapping['medium'];
};
// box size
const [Box] = useState('center');
const Boxs = (Box) => {
  const mapping = {
      'top': { justifyContent:'start'},
      'center': { justifyContent: 'center'},
      'end': { justifyContent:'end'},
  };
  return mapping[Box] || mapping['center'];
};
//font direction
const [fontdirection] = useState('center');
const fontdirections = (fontdirection) => {
  const mapping = {
      'left': { alignItems:'start'},
      'center': { alignItems: 'center'},
      'right': { alignItems:'end'},
  };
  return mapping[fontdirection] || mapping['center'];
};
//title size
const [titlesize] = useState('medium');
const titlesizes = (titlesize) => {
  const mapping = {
      'small': { fontSize:'1rem'},
      'medium': { fontSize: '2rem'},
      'large': { fontSize:'3rem'},
  };
  return mapping[titlesize] || mapping['medium'];
};
//paragraph size
const [paragraphsize] = useState('medium');
const paragraphSize = (paragraphsize) => {
  const mapping = {
      'small': { fontSize:'1rem'},
      'medium': { fontSize: '2rem'},
      'large': { fontSize:'3rem'},
  };
  return mapping[paragraphsize] || mapping['medium'];
};
  const contaner = {
    'display': 'flex',
   ...boxdirection('left'),//change
   ...Displaysize('medium'),//display
    'width': '100%',
    'justifyContent': 'space-between',// change direction
    'border': '2px solid black',
  }
  const box = {
    'display': 'flex',
    'flexDirection': 'column',
    ...Boxs('center'),
    ...fontdirections('center'),// font direction
    'margin': '10px',
    'height': '18rem',
    'width': '50%',
    'borderRadius': '5px',
  }
  const p = {
    ...paragraphSize('small'),
    'margin': '10px',
  }
  const buttonstyle = {
    'height': '2rem',
    'width': '5rem',
    'borderRadius': '0.5rem',
    'backgroundColor': 'black',
    'color': 'white',
  }
  const h3style = {
    ...titlesizes('medim'),
  }
  const title = 'Title'
  const paragraph = 'this is very much follow the leader'
  const button = 'Click'
  return (
    <>
   <div style={contaner}>
        <div style={box}>
          <h3 style={h3style}>{title}</h3>
          <p style={p}>{paragraph}</p>
          <button style={buttonstyle}>{button}</button>
        </div>
        <div style={box}>
          <h3 style={h3style}>{title}</h3>
          <p style={p}>{paragraph}</p>
          <button style={buttonstyle}>{button}</button>
        </div>
      </div>
    </>
  );
};

export default Cardrow;