import React, { useState, useEffect } from 'react';
import ProductGrid from './ProductGrid';
import styled from 'styled-components';

const ProductsContainer = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
`;

function Products(props) {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Load product data from JSON file
    import('../data/products.json')
      .then(data => {
        setProducts(data.default);
        setLoading(false);
      })
      .catch(error => {
        console.error('Error loading product data:', error);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return <div style={{ textAlign: 'center', padding: '2rem' }}>Loading products...</div>;
  }

  return (
    <ProductsContainer>
      <ProductGrid products={products} column={props.column} />
    </ProductsContainer>
  );
}

export default Products;