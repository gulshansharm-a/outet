import React from 'react';
import styled from 'styled-components';

const Card = styled.div`
  background-color: white;
  display: flex;
  flex-direction: column;
  transition: transform 0.2s;
  
  &:hover {
    transform: translateY(-5px);
  }
`;

const ImageContainer = styled.div`
  width: 100%;
  position: relative;
`;

const Image = styled.img`
  width: 100%;
  height: auto;
  display: block;
  aspect-ratio: 1/1;
  object-fit: contain;
  background-color: #f9f9f9;
`;

const Content = styled.div`
  padding: 12px;
`;

const Brand = styled.div`
  color: #e95420;
  font-size: 12px;
  text-transform: uppercase;
  font-weight: bold;
  margin-bottom: 4px;
`;

const Name = styled.h3`
  font-size: 15px;
  font-weight: 500;
  margin-bottom: 4px;
`;

const Type = styled.p`
  font-size: 13px;
  color: #666;
  margin-bottom: 4px;
`;

const Colors = styled.p`
  font-size: 13px;
  color: #666;
  margin-bottom: 4px;
`;

const Price = styled.p`
  font-size: 14px;
  font-weight: 500;
  margin-top: 4px;
`;

const AvailabilityTag = styled.div`
  font-size: 12px;
  color: #e95420;
  margin-bottom: 4px;
  font-weight: 500;
`;

const ProductCard = ({ product }) => {
  const { 
    brand, 
    name, 
    type, 
    colors, 
    price, 
    image, 
    availability 
  } = product;

  return (
    <Card>
      <ImageContainer>
        <Image src={image} alt={name} />
      </ImageContainer>
      <Content>
        <Brand>{brand}</Brand>
        <Name>{name}</Name>
        <Type>{type}</Type>
        <Colors>{colors} Colour</Colors>
        {availability && (
          <AvailabilityTag>
            {availability === 'SNKRS' ? 'Available in SNKRS' : availability}
          </AvailabilityTag>
        )}
        <Price>MRP: ₹ {price.toLocaleString('en-IN')}</Price>
      </Content>
    </Card>
  );
};

export default ProductCard;