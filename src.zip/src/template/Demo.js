import React, { useState, useEffect } from 'react';
import './demo.css';

const Demo = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Fetch data from your JSON file
    fetch('/products.json')
      .then(response => response.json())
      .then(data => {
        setProducts(data);
        setLoading(false);
      })
      .catch(error => {
        console.error('Error fetching product data:', error);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return <div className="loading">Loading products...</div>;
  }

  return (
    <div className="product-carousel-container">
      <div className="product-carousel">
        {products.map(product => (
          <div key={product.id} className="product-card">
            {product.onSale && <div className="sale-tag">SALE</div>}
            <div className="product-image-container">
              <img src={product.imageUrl} alt={product.name} className="product-image" />
            </div>
            <div className="product-details">
              <h3 className="product-name">{product.name}</h3>
              <div className="product-rating">
                <span className="rating-score">{product.rating.score}</span>
                <span className="rating-stars">
                  {'★'.repeat(Math.floor(product.rating.score))}
                  {'☆'.repeat(5 - Math.floor(product.rating.score))}
                </span>
                <span className="rating-count">{product.rating.count}</span>
              </div>
              <div className="product-price">
                <span className="current-price">₹{product.price.current.toLocaleString()}</span>
                {product.price.original && (
                  <span className="original-price">₹{product.price.original.toLocaleString()}</span>
                )}
              </div>
              <div className="product-seller">
                <span>{product.seller}</span>
                <span className="delivery-info">₹{product.deliveryCharge} delivery</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Demo;