import React, { useState } from "react";
import { Carousel } from 'antd';

const Image = [{ id: 1, name: 'https://images.unsplash.com/photo-1508349937151-22b68b72d5b1?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', title: "Exclusive Collection 1", description: "Discover the latest trends in fashion.", Message: "Sensors. useBattery — tracks device battery state. useGeolocation — tracks geo locatio" },
  { id: 2, name: 'https://plus.unsplash.com/premium_photo-1675826774815-35b8a48ddc2c?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', title: "Luxury Edition", description: "Upgrade your style with premium fashion.", Message: "Sensors. useBattery — tracks device battery state. useGeolocation — tracks geo locatio" },
  { id: 3, name: 'https://images.unsplash.com/photo-1528994618239-4d83bbdb7a0f?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', title: "Modern Elegance", description: "Shop timeless pieces that never go out of style.", Message: "Sensors. useBattery — tracks device battery state. useGeolocation — tracks geo locatio" }];
  
  const buttonStyle = {
    'position': "absolute",
    'padding': "10px 20px",
    'fontSize': "1rem",
    'backgroundColor': "#ff6600",
    'color': "white",
    'border': "none",
    'cursor': "pointer",
    'borderRadius': "10px",
  }
  
  const descriptionStyle = {
    'position': "absolute",
  }
  
  const Message = {
    'display': 'flex',
    'justifyContent': 'center',
    'alignItems': 'center',
  }
  
  const buttonname = 'Click';
  
  const centercontainer = {
    'display': 'flex',
    'position': 'relative',
    'flexWrap': 'wrap',
    'alignItems': 'center',
    'justifyContent': 'center',
    'alignContent': 'stretch'
  }
  
  const links = () => {
    window.location.href = 'https://www.google.com';
  };
    const Slider = () => {
   //contanter-style
   const [alignment] = useState('center-center');
   const getFlexStyles = (alignment) => {
     const mapping = {
         'topleft': { justifyContent: 'flex-start', alignItems: 'flex-start' },
         'topcenter': { justifyContent: 'center', alignItems: 'flex-start' },
         'topright': { justifyContent: 'flex-end', alignItems: 'flex-start' },
         'centerleft': { justifyContent: 'flex-start', alignItems: 'center' },
         'center-center': { justifyContent: 'center', alignItems: 'center' },
         'centerright': { justifyContent: 'flex-end', alignItems: 'center' },
         'bottomleft': { justifyContent: 'flex-start', alignItems: 'flex-end' },
         'bottomcenter': { justifyContent: 'center', alignItems: 'flex-end' },
         'bottomright': { justifyContent: 'flex-end', alignItems: 'flex-end' },
     };
     return mapping[alignment] || mapping['center-center'];
 };
 //button style 
 const [buttonstyle] = useState('center');
 const getbuttonStyles = (buttonstyle) => {
   const mapping = {
       'left': { justifyContent: 'flex-start'},
       'center': { justifyContent: 'center'},
       'right': { justifyContent: 'flex-end'},
   };
   return mapping[buttonstyle] || mapping['center'];
 };
 //Image-style
 const [imagestyle] = useState('center');
 const getimageStyles = (imagestyle) => {
   const mapping = {
     'small': { height:'40vh'},
     'medium': { height:'60vh'},
     'full': { height: '80vh'},
     };
     return mapping[imagestyle] || mapping['medium'];
     };
  return (
    <>
   <Carousel autoplay autoplaySpeed={2000} >
        {
          Image.map((img) => (
              <div style={centercontainer}>
                <div style={{ height: '100%', width: '100%',position:'absolute',display:'flex',...getFlexStyles('center-center')}}>
                    <div style={{padding:'1rem',display:'flex',height:'17rem',width:'25rem',position:'absolute',borderRadius:'1rem',backgroundColor:'rgba(184, 176, 176, 0.422)'}}>
                      <h2 style={descriptionStyle}>
                        {img.description}
                      </h2>
                      <p style={Message}>
                        {img.Message}
                      </p>
                     <div style={{display:'flex',position:'absolute',height:'100%',width:'95%',top:'-10px',alignItems:'end',...getbuttonStyles('center')}}> 
                      <button
                        style={buttonStyle}
                        onClick={links}>
                        {buttonname}
                      </button>
                    </div>  
                  </div>
                </div>
                <img style={{width:'100%',objectFit: 'cover',...getimageStyles('full')}} src={img.name} />
              </div>
          ))
        }
      </Carousel>
  </>
  );
};

export default Slider;
