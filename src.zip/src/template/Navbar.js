import { useGetSettingByID } from '../helper/section';
const navarray = [
  {id:1, name:'Enter1',settingId:121,value:'default'},
  {id:2, name:'Enter1',settingId:122,value:'default'},
  {id:3, name:'Enter1',settingId:123,value:'default'},
]

const Navbar = ({ sectionId }) => {
    const defaultValue = useGetSettingByID(sectionId, 1);

    return (
      <>
      {defaultValue} {sectionId}
      <h1 style={{ color: defaultValue }}>i</h1></>
       
    );
};

export { Navbar, navarray };
