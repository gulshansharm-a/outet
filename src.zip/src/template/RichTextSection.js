import React, { useState } from 'react';

const RichText = () => {
    const [contentPosition, setContentPosition] = useState('center');
    const [contentAlignment, setContentAlignment] = useState('center');
    const [isFullWidth, setIsFullWidth] = useState(false);

    // Function to get styles based on position
    const getPositionStyles = (position) => ({
        display: 'flex',
        justifyContent: position === 'left' ? 'flex-start' :
                      position === 'right' ? 'flex-end' : 'center',
    });

    // Function to get styles based on text alignment
    const getAlignmentStyles = (alignment) => ({
        textAlign: alignment,
    });

    return (
        <div style={{ padding: '20px' }}>
            {/* Controls (Always on top) */}
            <div style={{ marginBottom: '20px', padding: '10px', border: '1px solid #ddd' }}>
                <h4>Controls</h4>
                
                <label>Content Position:</label>
                <button onClick={() => setContentPosition('left')}>Left</button>
                <button onClick={() => setContentPosition('center')}>Center</button>
                <button onClick={() => setContentPosition('right')}>Right</button>
                
                <br /><br />

                <label>Content Alignment:</label>
                <button onClick={() => setContentAlignment('left')}>Left</button>
                <button onClick={() => setContentAlignment('center')}>Center</button>
                <button onClick={() => setContentAlignment('right')}>Right</button>

                <br /><br />

                <label>Full Width:</label>
                <input type="checkbox" checked={isFullWidth} onChange={() => setIsFullWidth(!isFullWidth)} />
            </div>

            {/* Rich Text Content (Moves based on controls) */}
            <div style={{ 
                width: isFullWidth ? '100%' : '80%', 
                margin: '0 auto', 
                padding: '20px', 
                border: '1px solid #ccc', 
                ...getPositionStyles(contentPosition)
            }}>
                <div style={{ maxWidth: '600px', ...getAlignmentStyles(contentAlignment) }}>
                    <h3>Rich Text Section</h3>
                    <p>This is an editable rich text section.</p>
                </div>
            </div>
        </div>
    );
};

export default RichText;
