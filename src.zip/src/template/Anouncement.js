import React,{ useState, useEffect } from "react";
const navarray = [{}]
const Announcement = () => {
  
  var autoRotation = false;
  var Change_every = 1;
  var AnnouncementArray = ["Welcome To store","10% off on T-shirts"]
  var Color_scheme =["Scheme 1","Scheme 2","Scheme 3","Scheme 4"]
  var Separator_line=false;
  
  const [index, setIndex] = useState(0);

  // Change text index every 3 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setIndex((prevIndex) => (prevIndex + 1) % AnnouncementArray.length);
    }, 3000);
    
    return () => clearInterval(interval); // Clean up on component unmount
  }, []);

  //css
  const background={
     'display':'flex',
     'justify-content':'center',
     'align-items': 'center',
     'color':'black',
     'background-color':'rgb(200, 200, 200)',
     'font-size':'0.90rem',
     'height':'2rem',
     'border-radius':'15px 15px 0 0',
  };

  return (
   <>
    <div style={background} >
      {AnnouncementArray[index]}
    </div>
   </>
  );
};

export { Announcement, navarray};
