import React, { useState } from 'react'
const navarray = [{}]

const Collections = () => {
    const collections = [
        {
          name: "Your collection's name",
          image: "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D", // Replace with actual image path
        },
        {
          name: "Your collection's name",
          image: "https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?q=80&w=1528&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
        },
        {
          name: "Your collection's name",
          image: "https://images.unsplash.com/photo-1600185365926-3a2ce3cdb9eb?q=80&w=1450&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
        },
      ];
    
      // Styles stored as JavaScript objects
      const styles = {
        container: {
          padding: "20px",
          maxWidth: "1000px",
          margin: "auto",
          textAlign: "center",
        },
        title: {
          fontSize: "24px",
          fontWeight: "bold",
          marginBottom: "15px",
        },
        collectionGrid: {
          display: "flex",
          justifyContent: "space-between",
          gap: "15px",
        },
        collectionCard: {
          width: "30%",
          padding: "15px",
          borderRadius: "10px",
          boxShadow: "0px 2px 5px rgba(0,0,0,0.1)",
          textAlign: "center",
          backgroundColor: "#fff",
        },
        image: {
          width: "100%",
          height: "auto",
          borderRadius: "8px",
        },
        collectionName: {
          fontSize: "16px",
          fontWeight: "bold",
          marginTop: "10px",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          gap: "5px",
          cursor: "pointer",
        },
      };
    return (
        <>
          <div style={styles.container}>
      <h2 style={styles.title}>Collections</h2>
      <div style={styles.collectionGrid}>
        {collections.map((collection, index) => (
          <div key={index} style={styles.collectionCard}>
            <img src={collection.image} alt={collection.name} style={styles.image} />
            <p style={styles.collectionName}>
              {collection.name} ➝
            </p>
          </div>
        ))}
      </div>
    </div>
        </>
    );
};

export { Collections, navarray };