import React, { useState } from 'react'
const navarray = [{}]

const Page = () => {
    const [fontsize] = useState('medium');
    const size = (fontsize) => {
      const mapping = {
          'small': { fontSize:'1rem'},
          'medium': { fontSize: '2rem'},
          'large': { fontSize: '3rem'},
      };
      return mapping[fontsize] || mapping['medium'];
    };
  
    const h1={
      'paddingTop':'1rem',
      ...size('medium'),
   }
    return(
        <>
  <h1 style={h1}>Page Title</h1>
        </>
    );
};

export { Page, navarray};