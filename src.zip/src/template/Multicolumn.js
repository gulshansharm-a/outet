import React, { useState } from 'react'
const navarray = [{}]

const Multicolumn = () => {
  //button style 
  const [displaysize] = useState('center');

  const displaysizes = (displaysize) => {
    const mapping = {
      'full': { height: '90vh' },
      'medium': { height: '70vh' },
      'small': { height: '40vh' },
    };
    return mapping[displaysize] || mapping['medium'];
  };
  //button style 
  const [buttonstyle] = useState('center');
  const getbuttonStyles = (buttonstyle) => {
    const mapping = {
      'left': { justifyContent: 'flex-start' },
      'center': { justifyContent: 'center' },
      'right': { justifyContent: 'flex-end' },
    };
    return mapping[buttonstyle] || mapping['center'];
  };

  const contaner = {
    'display': 'flex',
    'border': '2px solid black',
    'flexDirection': 'column',
    ...displaysizes('full'),
    'position': 'relative',
  }
  const h2 = {
    'padding': '1rem',
  }
  const boxsize = {
    'display': 'flex',
  }
  const paragrpah = {
    'fontSize': '1rem',
  }
  const button = {
    'position': 'absolute',
    'fontSize': '1.2rem',
    'width': '10rem',
    'padding': '0.4rem',
    'margin': '1rem auto',
    'backgroundColor': 'darkgrey',
  }
  const box = {
    'padding': '10px',
    'margin': '0 auto',
    'height': '20vh',
    'width': '30vw',
    'border': '2px solid black',
  }
  const buttondiv = {
    'display': 'flex',
    'height': '3rem',
    'alignItems': 'center',
    ...getbuttonStyles('center'),
  }
  const Title = 'Multi Column'
  const ColumnTitle = 'Column'
  const letter = 'Pair text with an image to focus on your chosen product, collection, or blog post. Add details on availability, style, or even provide a review.'
  const buttonname = 'Click Here'
  return (
    <>
      <div style={contaner}>
        <h2>{Title}</h2>
        <div style={boxsize}>
          <div style={box}>
            <h4>{ColumnTitle}</h4>
            <p style={paragrpah}>{letter}</p>
          </div>
          <div style={box}>
            <h4>{ColumnTitle}</h4>
            <p style={paragrpah}>{letter}</p>
          </div>
          <div style={box}>
            <h4>{ColumnTitle}</h4>
            <p style={paragrpah}>{letter}</p>
          </div>
        </div>
        <div style={buttondiv}>
          <button style={button}>{buttonname}</button>
        </div>
      </div>
    </>
  );
};

export { Multicolumn, navarray };