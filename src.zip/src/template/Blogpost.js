import React, { useState } from 'react'
const navarray = [{}]


const Blogpost = () => {
    const blogData = [
        {
          title: "Blog post",
          summary: "Give your customers a summary of your blog post",
          image: "https://images.unsplash.com/photo-1488190211105-8b0e65b80b4e?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D", // Replace with actual image paths
        },
        {
          title: "Blog post",
          summary: "Give your customers a summary of your blog post",
          image: "https://images.unsplash.com/photo-1606069905547-13ef544005a3?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
        },
        {
          title: "Blog post",
          summary: "Give your customers a summary of your blog post",
          image: "https://plus.unsplash.com/premium_photo-1664008628908-3deeb5b206bf?q=80&w=1471&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
        },
      ];
    
      // Variables for styles
      const styles = {
        container: {
          padding: "20px",
          maxWidth: "1000px",
          margin: "auto",
        },
        title: {
          fontSize: "24px",
          fontWeight: "bold",
          marginBottom: "15px",
        },
        postsContainer: {
          display: "flex",
          justifyContent: "space-between",
        },
        postCard: {
          width: "30%",
          padding: "15px",
          borderRadius: "10px",
          boxShadow: "0px 2px 5px rgba(0,0,0,0.1)",
          textAlign: "center",
          backgroundColor: "#fff",
        },
        image: {
          width: "100%",
          height: "auto",
          borderRadius: "8px",
        },
        postTitle: {
          fontSize: "18px",
          fontWeight: "bold",
          marginTop: "10px",
        },
        summary: {
          fontSize: "14px",
          color: "#555",
        },
      };
    
return(
<>
<div style={styles.container}>
      <h2 style={styles.title}>Blog posts</h2>
      <div style={styles.postsContainer}>
        {blogData.map((post, index) => (
          <div key={index} style={styles.postCard}>
            <img src={post.image} alt={post.title} style={styles.image} />
            <h3 style={styles.postTitle}>{post.title}</h3>
            <p style={styles.summary}>{post.summary}</p>
          </div>
        ))}
      </div>
    </div>
</>
);
};
export { Blogpost, navarray };