import React, { useState } from 'react'
const navarray = [{}]

const Image = [{ id: 1, name: 'https://images.unsplash.com/photo-1508349937151-22b68b72d5b1?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', title: "Exclusive Collection 1", description: "Discover the latest trends in fashion.", Message: "Sensors. useBattery — tracks device battery state. useGeolocation — tracks geo locatio" }];

const centercontainer = {
  'display': 'flex',
  'position': 'relative',
  'flexWrap': 'wrap',
  'alignItems': 'center',
  'justifyContent': 'center',
  'alignContent': 'stretch',
}

const ImageBanner = () => {
    const [alignment] = useState('center-center');
    const getFlexStyles = (alignment) => {
      const mapping = {
          'topleft': { justifyContent: 'flex-start', alignItems: 'flex-start' },
          'topcenter': { justifyContent: 'center', alignItems: 'flex-start' },
          'topright': { justifyContent: 'flex-end', alignItems: 'flex-start' },
          'centerleft': { justifyContent: 'flex-start', alignItems: 'center' },
          'center-center': { justifyContent: 'center', alignItems: 'center' },
          'centerright': { justifyContent: 'flex-end', alignItems: 'center' },
          'bottomleft': { justifyContent: 'flex-start', alignItems: 'flex-end' },
          'bottomcenter': { justifyContent: 'center', alignItems: 'flex-end' },
          'bottomright': { justifyContent: 'flex-end', alignItems: 'flex-end' },
      };
      return mapping[alignment] || mapping['center-center'];
  };
  //button style 
  const [buttonstyle] = useState('center');
  const getbuttonStyles = (buttonstyle) => {
    const mapping = {
        'left': { justifyContent: 'flex-start'},
        'center': { justifyContent: 'center'},
        'right': { justifyContent: 'flex-end'},
    };
    return mapping[buttonstyle] || mapping['center'];
  };
  //Image-style
  const [imagestyle] = useState('center');
  const getimageStyles = (imagestyle) => {
    const mapping = {
      'small': { height:'40vh'},
      'medium': { height:'60vh'},
      'full': { height: '80vh'},
      };
      return mapping[imagestyle] || mapping['medium'];
      };
  
      const [contanter] = useState('OFF');
  const contantercolor = (contanter) => {
    const mapping = {
      'ON': { backgroundColor:'rgba(0,0,0, 0.422)'},
      'OFF': { backgroundColor:'rgba(184, 176, 176, 0.422)'},
      };
      return mapping[contanter] || mapping['medium'];
      };
  
      const [h3styles] = useState('OFF');
      const Title = (contanter) => {
        const mapping = {
          'left': { alignSelf: 'flex-start'},
          'center': { alignSelf: 'center'},
          'right': { alignSelf: 'flex-end'},
      };
          return mapping[contanter] || mapping['medium'];
          };
      
     const box={
      'display':'flex',
      'flexDirection':'column',
      'height':'14vw',
      'justifyContent':'center',
      'alignItems':'center',
     'backgroundColor':'rgba(184, 176, 176, 0.422)',
     } 
    
     const button={
      'width':'100%',
      'display':'flex',
      'alignItems':'center',
      ...getbuttonStyles('center'),  /* button left-center-end  */
     }
     
     const buttonstyles={
      'margin':'4px',
      'padding':'10px 20px',
      'fontSize':'1rem',
      'backgroundColor':'#ff6600',
       'color':'white',
      'border':'none',
      'cursor':'pointer',
      'borderRadius':'10px',
     }
    
     const h3style={
      'fontSize':'1.5rem',
      ...Title('center'), //left Center End
     }
     const h3='Image banner'
     const paragraph='Give customers details about the banner image(s) or content on the template.'
     const button_1='Button-1'
     const button_2='Button-2'
    return (
        <>
           {
          Image.map((img) => (
              <div style={centercontainer}>
                <div style={{ height: '100%',width: '100%',position:'absolute',display:'flex',...getFlexStyles('center-center')}}>
                    <div style={box}>
                    <h3 style={h3style}>{h3}</h3>
                    <p>{paragraph}</p>
                    <div style={button}>
                    <button style={buttonstyles}>{button_1}</button>
                    <button style={buttonstyles}>{button_2}</button>
                    </div>
                  </div>
                </div>
                <img style={{width:'100%',objectFit: 'cover',...getimageStyles('full')}} src={img.name} />
              </div>
          ))
        }
        </>
    );
};

export { ImageBanner, navarray};