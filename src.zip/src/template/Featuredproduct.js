import React, { useState } from 'react'
const navarray = [{}]

const productlink = 'https://plus.unsplash.com/premium_photo-1679913792906-13ccc5c84d44?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'

const Title = 'Example product title'
const Rate = 'Rs:19.19'
const Quantity = 'Quantity'

const buttonname = 'Sold Out'
const p = 'Share'
const details = 'View full Details'


const left = {
    'display': 'flex',
    'justify-content': 'center',
    'align-items': 'center',
    'height': '100%',
    'width': '50%',
}
const right = {
    'height': '100%',
    'width': '27rem',
}
const Image = {
    'border-radius': '2rem',
    'width': '30rem',
    'height': '20rem',
}
const h1style = {
    'font-size': '3rem'
}

const rate = {
    'font-size': '1.5rem',
}
const formstyle = {
    'width': '30%',
    'padding': '0.30rem',
}
const inputstyle = {
    'height': '2rem',
    'width': '2rem',
    'font-size': '1.25rem',
    'border': 'none',
}
const buttonstyle = {
    'border': 'none',
    'width': '2rem',
    'height': '2.5rem',
}
const Quantitystyle = {
    'font-size': '1.5rem',
    'padding': 'auto',
}
const borderbutton = {
    'display': 'flex',
    'justify-content': 'space-between',
    'align-items': 'center',
    'width': '8rem',
    'border': '2px solid black',
}
const soldoutbutton = {
    'width': '100%',
    'height': '2rem',
    'background-color': 'darkgray',
    'border': '2px solid black',
}
const box = {
    'display': 'flex',
    'flex-direction': 'row',
    'justify-content': 'space-between',
    'align-items': 'center',
    'padding': '2rem',
}
const a = {
    'color': 'black',
}
const Featuredproduct = () => {
    const [count, setCount] = useState(0);

    const [displayPosition] = useState('left');
    const display = (displayPosition) => {
        const mapping = {
            'left': { flexDirection: 'row' },
            'right': { flexDirection: 'row-reverse' },
        };
        return mapping[displayPosition] || mapping['center'];
    };
    return (
        <>
            <div style={{ 'display': 'flex', 'height': '30rem', 'width': '100%', ...display('right'), }}>
                <div style={left}>
                    <img style={Image} src={productlink} />
                </div>
                <div style={right}>
                    <h1 style={h1style}>{Title}</h1>
                    <p style={rate}>{Rate}</p>
                    <div style={formstyle}>
                        <label style={Quantitystyle} for="input">{Quantity}</label>
                        <div style={borderbutton}>
                            <button style={buttonstyle} onClick={() => setCount(count - 1)}>-</button>
                            <input style={inputstyle} type="text" id='input' value={count} />
                            <button style={buttonstyle} onClick={() => setCount(count + 1)}>+</button>
                        </div>
                    </div>
                    <button style={soldoutbutton}>{buttonname}</button>
                    <div style={box}>
                        <p>{p}</p>
                        <a style={a} href="#">{details}</a>
                    </div>
                </div>
            </div>
        </>
    );
};

export { Featuredproduct, navarray };