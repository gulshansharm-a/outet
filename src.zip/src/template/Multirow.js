import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import './Multirow.css';

const sectionsData = [
  {
    id: 1,
    title: 'Feature One',
    description: 'This text with an image to focus on your chosen product, collection, or blog post. Add details on availability, style, or even provide a review.',
    buttonText: 'Explore more',
    imagePosition: 'left',
  },
  {
    id: 2,
    title: 'Feature Two',
    description: 'This text with an image to focus on your chosen product, collection, or blog post. Add details on availability, style, or even provide a review.',
    buttonText: 'Learn more',
    imagePosition: 'right',
  },
  {
    id: 3,
    title: 'Feature Three',
    description: 'This text with an image to focus on your chosen product, collection, or blog post. Add details on availability, style, or even provide a review.',
    buttonText: 'Get started',
    imagePosition: 'left',
  }
];

const Multirow = () => {
  const [sections, setSections] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  // Simulate data loading
  useEffect(() => {
    setTimeout(() => {
      setSections(sectionsData);
      setIsLoading(false);
    }, 1000);
  }, []);

  if (isLoading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Loading amazing content...</p>
      </div>
    );
  }

  return (
    <div className="app-container">
      <header className="header">
        <h1>Modern Features Showcase</h1>
        <p>Discover our amazing products and services</p>
      </header>

      <div className="sections-container">
        {sections.map((section, index) => (
          <Section key={section.id} section={section} index={index} />
        ))}
      </div>

      <footer className="footer">
        <p>© 2025 Your Amazing Company. All rights reserved.</p>
      </footer>
    </div>
  );
};

const Section = ({ section, index }) => {
  const { title, description, buttonText, imagePosition } = section;

  return (
    <motion.div 
      className={`section ${imagePosition === 'right' ? 'reverse' : ''}`}
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.2 }}
    >
      <motion.div 
        className="image-container"
        whileHover={{ scale: 1.05 }}
        transition={{ type: "spring", stiffness: 300 }}
      >
        <img 
          src={`https://fastly.picsum.photos/id/7/4728/3168.jpg?hmac=c5B5tfYFM9blHHMhuu4UKmhnbZoJqrzNOP9xjkV4w3o`} 
          alt={`Feature ${index + 1}`} 
          className="feature-image" 
        />
      </motion.div>
      
      <motion.div 
        className="content-container"
        initial={{ opacity: 0, x: imagePosition === 'right' ? -30 : 30 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.7, delay: index * 0.3 }}
      >
        <h2>{title}</h2>
        <p>{description}</p>
        <motion.button 
          className="action-button"
          whileHover={{ scale: 1.05, backgroundColor: '#0056b3' }}
          whileTap={{ scale: 0.95 }}
        >
          {buttonText}
        </motion.button>
      </motion.div>
    </motion.div>
  );
};

export default Multirow;