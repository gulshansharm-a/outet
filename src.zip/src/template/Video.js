import React, { useState } from "react";

const Video = () => {
  const [selectedOption, setSelectedOption] = useState("youtube");
  const [videoFile, setVideoFile] = useState(null);
  const [thumbnail, setThumbnail] = useState(null);
  const [autoplay, setAutoplay] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false); // Controls if video is playing

  const styles = {
    container: { padding: "20px", textAlign: "center" },
    title: { fontSize: "18px", fontWeight: "bold", marginBottom: "10px" },
    select: { padding: "8px", marginBottom: "15px", fontSize: "16px" },
    videoWrapper: {
      width: "100%",
      maxWidth: "800px",
      aspectRatio: "16 / 9",
      margin: "0 auto",
      position: "relative",
      borderRadius: "8px",
      overflow: "hidden",
      boxShadow: "0 4px 6px rgba(0,0,0,0.1)"
    },
    iframe: {
      width: "100%",
      height: "100%",
      position: "absolute",
      top: 0,
      left: 0,
      border: "none"
    },
    video: {
      width: "100%",
      height: "100%",
      objectFit: "cover",
      borderRadius: "8px"
    },
    thumbnail: {
      width: "100%",
      height: "100%",
      objectFit: "cover",
      cursor: "pointer",
      position: "absolute",
      top: 0,
      left: 0,
      zIndex: 2,
      borderRadius: "8px"
    },
    fileInput: { marginTop: "10px" },
    toggleWrapper: { display: "flex", alignItems: "center", gap: "10px", marginBottom: "15px" }
  };

  const handleVideoChange = (event) => {
    setVideoFile(URL.createObjectURL(event.target.files[0]));
  };

  const handleThumbnailChange = (event) => {
    setThumbnail(URL.createObjectURL(event.target.files[0]));
  };

  return (
    <div style={styles.container}>
      <h3 style={styles.title}>Select Media Type</h3>

      {/* Dropdown to choose between YouTube or Uploaded Video */}
      <select 
        style={styles.select} 
        value={selectedOption} 
        onChange={(e) => { 
          setSelectedOption(e.target.value); 
          setIsPlaying(false); // Reset playing state when switching 
        }}
      >
        <option value="youtube">YouTube Video</option>
        <option value="upload">Uploaded Video</option>
      </select>

      {/* Thumbnail Upload */}
      <div>
        <h4>Upload Custom Thumbnail</h4>
        <input type="file" accept="image/*" style={styles.fileInput} onChange={handleThumbnailChange} />
      </div>

      {/* Autoplay Toggle */}
      <div style={styles.toggleWrapper}>
        <label>Autoplay:</label>
        <input type="checkbox" checked={autoplay} onChange={() => setAutoplay(!autoplay)} />
      </div>

      <div style={styles.videoWrapper}>
        {/* Show Thumbnail Until Clicked */}
        {!isPlaying && thumbnail && (
          <img src={thumbnail} alt="Thumbnail" style={styles.thumbnail} onClick={() => setIsPlaying(true)} />
        )}

        {isPlaying && selectedOption === "youtube" ? (
          <iframe
            style={styles.iframe}
            src={`https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=${autoplay ? 1 : 0}`}
            title="YouTube Video"
            allow={autoplay ? "autoplay" : ""}
            allowFullScreen
          ></iframe>
        ) : isPlaying && selectedOption === "upload" ? (
          <>
            <input type="file" accept="video/*" style={styles.fileInput} onChange={handleVideoChange} />
            {videoFile && (
              <video style={styles.video} controls autoPlay={autoplay}>
                <source src={videoFile} type="video/mp4" />
                Your browser does not support the video tag.
              </video>
            )}
          </>
        ) : null}
      </div>
    </div>
  );
};

export default Video;
