import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import React, { useState} from "react";


const companyLinks = [
  { name: "About", url: "www.google.com" },
  { name: "Features", url: "www.google.com" },
  { name: "Works", url: "www.google.com" },
  { name: "Career", url: "www.google.com" }
];

const helpLinks = [
  { name: "Customer Support", url: "https://www.google.com" },
  { name: "Delivery Details", url: "https://www.google.com" },
  { name: "Terms & Conditions", url: "https://www.google.com" },
  { name: "Privacy Policy", url: "https://www.google.com" },
];

const faqlinks = [
  { name: "Account", url: "https://www.google.com" },
  { name: "Manage", url: "https://www.google.com" },
  { name: "Deliveries", url: "https://www.google.com" },
  { name: "Orders", url: "https://www.google.com" },
  { name: "Payments", url: "https://www.google.com"}
];

const resourcelinks = [
  { name: "Free eBooks", url: "https://www.google.com" },
  { name: "Development Tutorial", url: "https://www.google.com" },
  { name: "How to-Blog", url: "https://www.google.com" },
  { name: "Youtube Playlist", url: "https://www.google.com" },
]

const paymentlinks = [
  { name: "Free eBooks", url: "https://www.google.com" },
  { name: "Development Tutorial", url: "https://www.google.com" },
  { name: "How to-Blog", url: "https://www.google.com" },
  { name: "Youtube Playlist", url: "https://www.google.com" },
]

const navarray = [{}]
const Footer = () => {

  
  
  return (
    <footer className="bg-light py-4">
      
      <div className="container">
        <div className="row">
          {/* Left Section - Logo & Description */}
          <div className= "d-flex gap-3">
          <div className="col-md-3">
            <h5 className="fw-bold">SHOP.CO</h5>
            <p className="text-muted">We have clothes that suit your style and which you're proud to wear. From women to men.</p>
            
            <div className="d-flex gap-3">
              <a href="#" className="text-dark"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24"><path d="M23.953 4.569c-.885.389-1.83.654-2.825.775 1.014-.611 1.794-1.574 2.163-2.723-.951.564-2.005.974-3.127 1.195-.897-.957-2.173-1.555-3.591-1.555-2.717 0-4.92 2.203-4.92 4.917 0 .39.045.765.126 1.124C7.691 8.094 4.066 6.13 1.64 3.161c-.427.734-.666 1.581-.666 2.475 0 1.708.87 3.215 2.188 4.099-.807-.026-1.566-.248-2.228-.617v.061c0 2.385 1.693 4.374 3.946 4.828-.413.11-.849.171-1.296.171-.317 0-.626-.03-.927-.086.626 1.956 2.444 3.379 4.6 3.42-1.684 1.319-3.808 2.107-6.102 2.107-.396 0-.787-.023-1.175-.067 2.179 1.396 4.768 2.209 7.548 2.209 9.056 0 14.007-7.496 14.007-13.986 0-.209 0-.42-.015-.63.961-.695 1.8-1.562 2.46-2.549z"/></svg></a>
              <a href="#" className="text-dark"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24"><path d="M22.675 0h-21.35C.597 0 0 .597 0 1.325v21.351C0 23.403.597 24 1.325 24h11.497v-9.294H9.69V11.18h3.132V8.411c0-3.1 1.893-4.787 4.66-4.787 1.324 0 2.463.098 2.794.143v3.24h-1.917c-1.506 0-1.798.717-1.798 1.768v2.315h3.595l-.468 3.525h-3.127V24h6.127c.728 0 1.325-.597 1.325-1.324V1.325C24 .597 23.403 0 22.675 0z"/></svg></a>
              <a href="#" className="text-dark"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.849.07 1.366.062 2.633.328 3.608 1.304.975.976 1.242 2.243 1.304 3.608.058 1.265.07 1.645.07 4.849s-.012 3.584-.07 4.849c-.062 1.366-.328 2.633-1.304 3.608-.975.975-2.243 1.242-3.608 1.304-1.265.058-1.645.07-4.849.07s-3.584-.012-4.849-.07c-1.366-.062-2.633-.328-3.608-1.304-.975-.975-1.242-2.243-1.304-3.608-.058-1.265-.07-1.645-.07-4.849s.012-3.584.07-4.849c.062-1.366.328-2.633 1.304-3.608.975-.976 2.243-1.242 3.608-1.304 1.265-.058 1.645-.07 4.849-.07M12 0C8.741 0 8.332.013 7.052.072c-1.28.059-2.158.26-2.932.556-.795.304-1.471.71-2.145 1.384C1.301 2.786.895 3.462.591 4.257.295 5.031.094 5.909.035 7.189.013 8.469 0 8.879 0 12s.013 3.531.072 4.811c.059 1.28.26 2.158.556 2.932.304.795.71 1.471 1.384 2.145.674.674 1.35 1.08 2.145 1.384.774.296 1.652.497 2.932.556 1.28.059 1.689.072 4.949.072s3.669-.013 4.949-.072c1.28-.059 2.158-.26 2.932-.556.795-.304 1.471-.71 2.145-1.384.674-.674 1.08-1.35 1.384-2.145.296-.774.497-1.652.556-2.932.059-1.28.072-1.689.072-4.949s-.013-3.669-.072-4.949c-.059-1.28-.26-2.158-.556-2.932-.304-.795-.71-1.471-1.384-2.145-.674-.674-1.35-1.08-2.145-1.384C19.767.26 18.889.059 17.609.072 16.329.013 15.92 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zm0 10.162a3.999 3.999 0 110-7.998 3.999 3.999 0 010 7.998zm6.406-11.841a1.44 1.44 0 11-2.88 0 1.44 1.44 0 012.88 0z"/></svg></a>
              <a href="#" className="text-dark"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12c0 4.42 2.87 8.166 6.84 9.49.5.092.68-.216.68-.48 0-.237-.008-.866-.013-1.7-2.782.603-3.369-1.34-3.369-1.34-.454-1.153-1.11-1.46-1.11-1.46-.908-.62.07-.607.07-.607 1.004.07 1.533 1.033 1.533 1.033.892 1.53 2.34 1.09 2.91.833.09-.647.35-1.09.635-1.34-2.22-.25-4.56-1.11-4.56-4.95 0-1.09.39-1.98 1.03-2.68-.103-.25-.447-1.27.098-2.64 0 0 .84-.27 2.75 1.03A9.485 9.485 0 0 1 12 6.81c.85.004 1.71.115 2.51.34 1.91-1.3 2.75-1.03 2.75-1.03.545 1.37.202 2.39.1 2.64.64.7 1.03 1.59 1.03 2.68 0 3.85-2.34 4.69-4.57 4.94.36.31.68.92.68 1.86 0 1.34-.013 2.42-.013 2.75 0 .267.18.577.688.48C19.13 20.16 22 16.42 22 12c0-5.52-4.48-10-10-10z"/></svg></a>
            </div>
          </div>
  
          
         

      
      <div style={{ borderBottom: "1px solid #ddd", margin: "5px 0" }}></div>
      <hr className="my-2" /> 
      <ul className="list-unstyled">
      <h6 className="fw-bold">Company</h6>
        {companyLinks.map((link, index) => (
          <li key={index}>
            <a href={link.url} className="text-muted">{link.name}</a>
          </li>
        ))}
      </ul>
      
      
      <ul>
       <h6 className="fw-bold" textAlign = "center">Help</h6> 
        {helpLinks.map((link, index) => (
          <li key={index}>
            <a href={link.url} className="text-muted"> 
            {/* target="_blank" */}
              {link.name}
            </a>
          </li>
        ))}
      </ul>
    
      
      <ul>
      <h6 className="fw-bold">FAQ</h6> 
        {faqlinks.map((link, index) => (
          <li key={index}>
            <a href={link.url} className="text-muted" > 
            
              {link.name}
            </a>
          </li>
        ))}
      </ul>

      
      <ul>
        <h6 className="fw-bold">Resources</h6>
        {resourcelinks.map((link, index) => (
          <li key={index}>
            <a href={link.url} className="text-muted" > 
            
              {link.name}
            </a>
          </li>
        ))}
      </ul>

     </div>
          
        </div>

        <div className="d-flex justify-content-between align-items-center mt-4 border-top pt-3">
          <p className="text-muted m-0">Shop.co © 2000-2023, All Rights Reserved</p>
          <div>
            <img src="https://upload.wikimedia.org/wikipedia/commons/a/ac/Old_Visa_Logo.svg" alt="Visa" width="40" style={{ marginRight: "10px" }} />
            <img src="https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg" alt="PayPal" width="40"  style={{ marginRight: "10px" }} />
            <img src="https://upload.wikimedia.org/wikipedia/commons/2/2a/Mastercard-logo.svg" alt="Mastercard" width="40" style={{ marginRight: "10px" }} />
            <img src="https://www.apple.com/v/apple-pay/c/images/overview/apple_pay_logo__dzlko7dmroeq_large_2x.png" alt="Apple Pay" width="40" style={{ marginRight: "10px" }} />
            <img src="https://upload.wikimedia.org/wikipedia/commons/c/c7/Google_Pay_Logo.svg" alt="Google Pay" width="40" style={{ marginRight: "10px" }} />
          </div>
        </div>
      </div>
    </footer>

  );
};


export { Footer, navarray};