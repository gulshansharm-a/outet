import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import React, { useState } from "react";
const navarray = [
  {id:1, name:'Enter1',settingId:121,value:'default'},
  {id:2, name:'Enter1',settingId:122,value:'default'},
  {id:3, name:'Enter1',settingId:123,value:'default'},
]

const Navbar = ({ sectionId }) => {
  //change item
  const [chnageitem] = useState('Space');
  const display = (chnageitem) => {
    const mapping = {
        'left': { justifyContent:'start'},
        'right': { justifyContent: 'end'},
        'center': { justifyContent: 'center'},
        'Space': { justifyContent: 'space-between'},
    };
    return mapping[chnageitem] || mapping['Space'];
  };
//Change direction
const [chnagedirection] = useState('Space');
const displaydirection = (chnagedirection) => {
  const mapping = {
      'left': { flexDirection:'row'},
      'right': { flexDirection:'row-reverse'},
      'top': { flexDirection:'column'},
      'bottom': { flexDirection:'column-reverse'},
  };
  return mapping[chnagedirection] || mapping['left'];
};
//logo Size
const [logosize] = useState('medium');
const logosizes = (logosize) => {
  const mapping = {
      'small': { fontSize:'1rem'},
      'medium': { fontSize:'2rem'},
      'large': { fontSize:'3rem'},
  };
  return mapping[logosize] || mapping['medium'];
};
//navlinks
const [navlink] = useState('left');
const Navlinks = (navlink) => {
  const mapping = {
    'left': { flexDirection:'row'},
    'right': { flexDirection:'row-reverse'},
    'top': { flexDirection:'column'},
    'bottom': { flexDirection:'column-reverse'},
};
  return mapping[navlink] || mapping['left'];
};
//navlinksize
const [navlinksize] = useState('small');
const Navlinksize = (navlinksize) => {
  const mapping = {
    'small': { fontSize:'1rem'},
    'medium': { fontSize:'2rem'},
    'large': { fontSize:'2.5rem'},
};
  return mapping[navlinksize] || mapping['small'];
};

  const nav = {
    'display': 'flex',
    ...display('Space'),// change item
    ...displaydirection('left'),// change direction
    'alignItems': 'center',
    'backgroundColor': 'white',
    'padding': '10px 20px',
    'color': 'white',
    'border':'2px solid black',
  }
  const logo = {
    ...logosizes('medium'),
    'color': 'black',
    'textDecoration': 'none',
  }
  const navbarlogo = {
    'padding': '0.5rem',
    'display': 'flex',
  }
  const navlinks = {
    'listStyleType': 'none',
    'margin': '0',
    'padding': '0',
    'display': 'flex',
     ...Navlinks('left'),//change row column
  }
  const anchor = {
    'align-self':'start',
    ...Navlinksize('small'),//size change
    'color': 'black', //color change nav icon
    'textDecoration': 'none',
  }
  const li = {
    'margin': '0 15px',
  }

  const input = {
    'height': '1.50rem',
    'width': '15rem',
    'border': '2px solid black',
    'borderRadius': '5px',
    'backgroundColor': '#f9f9f9',
    'color': '#333',
  }
  const logolink='#'
  const home='#'
  const about='#'
  const services='#'
  const contact='#'
  const placeholder='Search'

  return (
    <>
     <nav style={nav}>
        <div style={navbarlogo}>
          <a style={logo} href={logolink}>SHOP.CO { sectionId } </a>
        </div>
        <ul style={navlinks}>
          <li style={li}><a style={anchor} href={home}>Home</a></li>
          <li style={li}><a style={anchor} href={about}>About</a></li>
          <li style={li}><a style={anchor} href={services}>Services</a></li>
          <li style={li}><a style={anchor} href={contact}>Contact</a></li>
          <li style={li}><div><input style={input} type="search" placeholder={placeholder}/></div></li>
        </ul>
        <div style={navbarlogo}>
          <div><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#000000"><path d="M234-276q51-39 114-61.5T480-360q69 0 132 22.5T726-276q35-41 54.5-93T800-480q0-133-93.5-226.5T480-800q-133 0-226.5 93.5T160-480q0 59 19.5 111t54.5 93Zm246-164q-59 0-99.5-40.5T340-580q0-59 40.5-99.5T480-720q59 0 99.5 40.5T620-580q0 59-40.5 99.5T480-440Zm0 360q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-80q53 0 100-15.5t86-44.5q-39-29-86-44.5T480-280q-53 0-100 15.5T294-220q39 29 86 44.5T480-160Zm0-360q26 0 43-17t17-43q0-26-17-43t-43-17q-26 0-43 17t-17 43q0 26 17 43t43 17Zm0-60Zm0 360Z" /></svg></div>
          <div><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="40px" fill="#000000"><path d="M480-569.33 433.33-616l70.34-70.67h-177v-66.66h177L433-824l47-46.67L630.67-720 480-569.33ZM286.53-80q-30.86 0-52.7-21.97Q212-123.95 212-154.81q0-30.86 21.98-52.69 21.97-21.83 52.83-21.83t52.69 21.97q21.83 21.98 21.83 52.84 0 30.85-21.97 52.69Q317.38-80 286.53-80Zm402.66 0q-30.86 0-52.69-21.97-21.83-21.98-21.83-52.84 0-30.86 21.97-52.69 21.98-21.83 52.84-21.83 30.85 0 52.69 21.97Q764-185.38 764-154.52q0 30.85-21.97 52.69Q720.05-80 689.19-80ZM54.67-813.33V-880h121l170 362.67H630.8l158.87-280h75L698-489.33q-11 19.33-28.87 30.66-17.88 11.34-39.13 11.34H328.67l-52 96H764v66.66H282.67q-40.11 0-61.06-33-20.94-33-2.28-67L280-496 133.33-813.33H54.67Z" /></svg></div>
        </div>
      </nav>
    </>
  );
};

export { Navbar, navarray };
