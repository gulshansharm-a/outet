import React, { useState } from 'react'
const navarray = [{}]

const Collage = () => {
    const [buttondisplay] = useState('Large');
    const display = (buttondisplay) => {
      const mapping = {
          'Small': { height:'60vh'},
          'Medium': { height: '70vh'},
          'Large': { height: '80vh'},
          'Extra large': { height: '90vh'},
          'Extra extra large': { height:'100vh'},
      };
      return mapping[buttondisplay] || mapping['Large'];
    };
  
    const [layout] = useState('Left');
    const layoutchange = (layout) => {
      const mapping = {
          'left': { flexDirection:'row'},
          'Right': { flexDirection:'row-reverse'},
      };
      return mapping[layout] || mapping['Left'];
    };
    const container = {
      'display': 'flex',
      'flexDirection': 'column',
      'width': '100%',
    }
    const box_style = {
      'display':'flex',
      ...layoutchange('left'), /* change layout */
      ...display('small'), /* change Display */
      'width':'100%',
    }
    const box = {
      'display': 'flex',
      'padding': '0.25rem',
      'height': '80vh',
      'width': '110vh',
      'flexDirection': 'column',
    }
    const box_1 = {
      'alignSelf': 'center',
      'alignSelf': 'center',
      'height': '50%',
      'width': '60%',
    }
    const Bigimage = {
      'height': '100%',
      'width': '100%',
    }
    const boximage1 = {
      'height': '11.12rem',
      'width': '100%',
    }
    const boximage2 = {
      'height': '12rem',
      'width': '100%',
    }
  
    const bigImageurl = 'https://plus.unsplash.com/premium_photo-1677838847721-2bf14b48c256?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'
    const boximge1 = 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?q=80&w=1399&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'
    const boximge2 = 'https://images.unsplash.com/photo-1583394838336-acd977736f90?q=80&w=1368&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'
  
    const Title = 'Multimedia collage'
    const p = 'Example Product Title'
    const rate = 'Rs.19.19'
    const Collection = 'Your Collection s name'
    
    return (
        <>
            <div style={container}>
                <h1>{Title}</h1>
                <div style={box_style}>
                    <div style={box}>
                        <img style={Bigimage} src={bigImageurl} />
                    </div>
                    <div style={box}>
                        <div style={box_1}>
                            <img style={boximage1} src={boximge1} />
                            <p>{p}</p>
                            <p>{rate}</p>
                        </div>
                        <div style={box_1}>
                            <img style={boximage2} src={boximge2} />
                            <h3>{Collection}</h3>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export { Collage, navarray };