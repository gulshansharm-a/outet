import {FirstComplete,FirstCompleteArray} from "../template/FirstComplete";
import { Navbar ,navarray} from "../template/Navbar";

    const SectionArray = [
        { id: 1221, name: "Temp", section: <FirstComplete />, array: FirstCompleteArray },
        { id: 1222, name: "Nav Bar", section: <Navbar />, array: navarray },
        
    ];




export default SectionArray;
