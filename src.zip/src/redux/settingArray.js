import TextField from "../setting/textField";


const settingArray = [
    { settingId: 121, setting: <TextField /> },
    
];

export default settingArray;
