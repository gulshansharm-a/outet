import './App.css';
import Panel from './designer/Panel';
import Uppernavbar from './Uppernavbar';

function App() {
  return (
    <div className="App">
      <Uppernavbar />
      <Panel />
    </div>
  );
}

export default App;
